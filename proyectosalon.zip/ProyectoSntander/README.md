# ProyectoSntander

Equipo 5 del curso de Desarrollo Móvil de Santander-Bedu


Integrantes del equipo: 

Jessica Córdova
Kenly Nallely López García
Laura Álvarez Guerrero
Rosa Sandoval



"BeautyFinder está planteada como una plataforma de búsqueda y contratación de servicios estéticos, tales como spa, uñas, cortes de pelo, tratamientos faciales y otros similares. De este modo, el usuario puede buscar y/o ofrecer estos servicios y realizar su contratación y pago desde una aplicación específicamente diseñada para este fin. "

Aunque originalmente está pensado únicamente para el rubro se servicios estéticos (de belleza), la estructura de la app permite su crecimiento para adpatarlo a otros servicios o bien para brindar dentro de una misma solución otros rubros. 

liga de google docs: https://docs.google.com/document/d/1s9yXzJ8G7zfp13yr4uEZoYFDMDHXhcEjIjo1t0xYvsk/edit?usp=sharing
