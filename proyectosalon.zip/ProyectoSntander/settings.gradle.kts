
rootProject.name = "proyectosalon"

