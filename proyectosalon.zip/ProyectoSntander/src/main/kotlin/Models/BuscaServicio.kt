package Models

class BuscarServicio(val categoria: CategoriaServicio,val nombreServicio: AltaServicio){

}