package Models

class CategoriaServicio(val categoria: List<String> = listOf("Cabello", "Tratamientos Faciales", "Depilación", "Uñas", "Eyebrows/Lashes", "Tratamientos Corporales")){
    //val categoria:String,
}
