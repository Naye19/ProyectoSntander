package Models

class PagoTarjeta(var usuario: UsuarioGeneral,val nombreCompleto: String, private var numerotarjeta: Int,private var Banco:String){

}