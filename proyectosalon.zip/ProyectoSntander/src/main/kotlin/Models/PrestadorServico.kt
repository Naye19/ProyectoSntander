package Models

class PrestadorServico (val nombreServicios: Servicios,val servicio: String, val telefono: Int,val correo: String){
}